<?php
    $id = $_GET["id_user"];
    echo "<script>document.location.href='formLagu.php?id_user=$id'</script>";
?>